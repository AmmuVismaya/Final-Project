package com.example.barterbay.dashboard

import androidx.lifecycle.ViewModel

class DashBoardViewModel: ViewModel() {

    fun getAllProducts(){}
}